import React, { useState } from 'react';
import { Recipe, RecipeCategory, Ingredient, CookingStep, PRESET_STICKERS, PRESET_WEATHER } from '../types/recipe';
import { CATEGORY_TAXONOMY, ALL_CATEGORIES_LIST, getSubcategoriesForCategory } from '../types/categories';
import { X, Plus, Trash2, Camera, Star, Check, Sparkles, ChefHat } from 'lucide-react';
import { compressImageFile } from '../utils/storage';

interface RecipeEditorProps {
  initialRecipe?: Recipe | null;
  onSave: (recipe: Recipe) => void;
  onCancel: () => void;
}

export const RecipeEditor: React.FC<RecipeEditorProps> = ({
  initialRecipe,
  onSave,
  onCancel
}) => {
  const isEditing = Boolean(initialRecipe);

  const [title, setTitle] = useState(initialRecipe?.title || '');
  const [subtitle, setSubtitle] = useState(initialRecipe?.subtitle || '');
  const [category, setCategory] = useState<RecipeCategory>(initialRecipe?.category || '烘焙甜点');
  const [subCategory, setSubCategory] = useState<string>(
    initialRecipe?.subCategory ||
      (initialRecipe?.category
        ? getSubcategoriesForCategory(initialRecipe.category)[0]?.id || '西式烘焙'
        : '西式烘焙')
  );

  const handleCategoryChange = (newCat: RecipeCategory) => {
    setCategory(newCat);
    const subList = getSubcategoriesForCategory(newCat);
    if (subList.length > 0) {
      setSubCategory(subList[0].id);
    }
  };
  const [cuisine, setCuisine] = useState(initialRecipe?.cuisine || '私房中式');
  const [prepTimeMinutes, setPrepTimeMinutes] = useState(initialRecipe?.prepTimeMinutes || 15);
  const [cookTimeMinutes, setCookTimeMinutes] = useState(initialRecipe?.cookTimeMinutes || 30);
  const [baseServings, setBaseServings] = useState(initialRecipe?.baseServings || 2);
  const [difficulty, setDifficulty] = useState(initialRecipe?.difficulty || 3);
  const [weatherStamp, setWeatherStamp] = useState(initialRecipe?.weatherStamp || '☀️ 晴暖好食');
  const [coverImage, setCoverImage] = useState(initialRecipe?.coverImage || '');
  const [utensilsText, setUtensilsText] = useState(initialRecipe?.utensils?.join('、') || '不粘煎锅、主厨刀');

  // Ingredients state
  const [ingredients, setIngredients] = useState<Ingredient[]>(
    initialRecipe?.ingredients || [
      { id: 'ing-1', name: '主料食材', amount: 300, unit: '克', category: 'main' },
      { id: 'ing-2', name: '生抽', amount: 2, unit: '汤匙', category: 'seasoning', note: '提鲜' },
      { id: 'ing-3', name: '小葱碎', amount: 1, unit: '小撮', category: 'garnish' }
    ]
  );

  // Steps state
  const [steps, setSteps] = useState<CookingStep[]>(
    initialRecipe?.steps || [
      {
        id: 'st-1',
        stepNumber: 1,
        title: '洗净切配与备料',
        description: '食材洗净后改刀切块备用，沥干水分。',
        durationMinutes: 10,
        heat: '中火',
        tip: '食材水分需用厨房纸吸干，避免入锅油花飞溅。'
      },
      {
        id: 'st-2',
        stepNumber: 2,
        title: '入锅烹饪与调味',
        description: '热锅凉油，下入调料煸炒出香气，均匀包裹食材翻炒。',
        durationMinutes: 15,
        heat: '大火'
      }
    ]
  );

  // Review & Reflection state
  const [tastingNotes, setTastingNotes] = useState(initialRecipe?.review?.tastingNotes || '');
  const [pitfallsAndLessons, setPitfallsAndLessons] = useState(initialRecipe?.review?.pitfallsAndLessons || '');
  const [pairingSuggestions, setPairingSuggestions] = useState(initialRecipe?.review?.pairingSuggestions || '');
  const [dinerFeedback, setDinerFeedback] = useState(initialRecipe?.review?.dinerFeedback || '');
  const [tasteRating, setTasteRating] = useState(initialRecipe?.review?.ratings?.taste || 5);
  const [reproducibilityRating, setReproducibilityRating] = useState(initialRecipe?.review?.ratings?.reproducibility || 5);
  const [selectedStickers, setSelectedStickers] = useState<string[]>(
    initialRecipe?.review?.stickers || ['🍚 米饭杀手', '✨ 满分硬菜']
  );
  const [cookDate, setCookDate] = useState(initialRecipe?.review?.cookDate || new Date().toISOString().slice(0, 10));

  const [activeTab, setActiveTab] = useState<'basic' | 'ingredients' | 'steps' | 'review'>('basic');
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  // Handle cover image upload
  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsProcessingImage(true);
      const base64 = await compressImageFile(file);
      setCoverImage(base64);
    } catch (err) {
      console.error('Image compression error', err);
    } finally {
      setIsProcessingImage(false);
    }
  };

  // Ingredient Helpers
  const addIngredientRow = (cat: 'main' | 'seasoning' | 'garnish') => {
    setIngredients([
      ...ingredients,
      {
        id: 'ing-' + Date.now() + Math.random().toString(36).substring(2, 6),
        name: '',
        amount: 1,
        unit: '份',
        category: cat,
        note: ''
      }
    ]);
  };

  const updateIngredient = (index: number, field: keyof Ingredient, value: unknown) => {
    const updated = [...ingredients];
    updated[index] = { ...updated[index], [field]: value };
    setIngredients(updated);
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  // Step Helpers
  const addStepRow = () => {
    setSteps([
      ...steps,
      {
        id: 'st-' + Date.now(),
        stepNumber: steps.length + 1,
        title: `步骤 ${steps.length + 1}`,
        description: '',
        durationMinutes: 5,
        heat: '中火'
      }
    ]);
  };

  const updateStep = (index: number, field: keyof CookingStep, value: unknown) => {
    const updated = [...steps];
    updated[index] = { ...updated[index], [field]: value };
    setSteps(updated);
  };

  const removeStep = (index: number) => {
    const updated = steps
      .filter((_, i) => i !== index)
      .map((s, idx) => ({ ...s, stepNumber: idx + 1 }));
    setSteps(updated);
  };

  // Toggle Sticker
  const toggleSticker = (sticker: string) => {
    if (selectedStickers.includes(sticker)) {
      setSelectedStickers(selectedStickers.filter((s) => s !== sticker));
    } else {
      setSelectedStickers([...selectedStickers, sticker]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('请输入食谱名称！');
      return;
    }

    const utensilsList = utensilsText
      .split(/[,，、]/)
      .map((u) => u.trim())
      .filter(Boolean);

    const recipe: Recipe = {
      id: initialRecipe?.id || 'recipe-' + Date.now(),
      title: title.trim(),
      subtitle: subtitle.trim(),
      category,
      subCategory: subCategory.trim(),
      cuisine: cuisine.trim(),
      prepTimeMinutes: Number(prepTimeMinutes) || 10,
      cookTimeMinutes: Number(cookTimeMinutes) || 15,
      baseServings: Number(baseServings) || 2,
      difficulty: Number(difficulty) || 3,
      coverImage: coverImage || '',
      weatherStamp,
      utensils: utensilsList.length > 0 ? utensilsList : ['常规锅具'],
      ingredients: ingredients.filter((i) => i.name.trim().length > 0),
      steps: steps.filter((s) => s.title.trim().length > 0 || s.description.trim().length > 0),
      review: {
        tastingNotes,
        pitfallsAndLessons,
        pairingSuggestions,
        ratings: {
          taste: tasteRating,
          difficulty,
          reproducibility: reproducibilityRating,
          presentation: 5
        },
        stickers: selectedStickers,
        dinerFeedback,
        cookDate
      },
      createdAt: initialRecipe?.createdAt || new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString().slice(0, 10),
      isFavorite: initialRecipe?.isFavorite ?? false
    };

    onSave(recipe);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[#FAF7F2] rounded-2xl border border-[#EADBCE] shadow-2xl max-w-3xl w-full my-6 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:px-6 border-b border-[#EADBCE] bg-white">
          <div className="flex items-center gap-2">
            <ChefHat className="w-5 h-5 text-[#C85A32]" />
            <h2 className="text-base sm:text-lg font-bold font-journal-title text-[#2C2723]">
              {isEditing ? '编辑烹饪手帐' : '记一笔新的私房菜谱'}
            </h2>
          </div>
          <button
            onClick={onCancel}
            className="p-1.5 text-[#9A9085] hover:text-[#2C2723] rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-[#EADBCE] bg-[#FAF7F2] text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('basic')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'basic' ? 'border-[#C85A32] text-[#C85A32] font-semibold' : 'border-transparent text-[#7A7268] hover:text-[#2C2723]'
            }`}
          >
            1. 基本信息与配图
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ingredients')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'ingredients' ? 'border-[#C85A32] text-[#C85A32] font-semibold' : 'border-transparent text-[#7A7268] hover:text-[#2C2723]'
            }`}
          >
            2. 食材清单 ({ingredients.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('steps')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'steps' ? 'border-[#C85A32] text-[#C85A32] font-semibold' : 'border-transparent text-[#7A7268] hover:text-[#2C2723]'
            }`}
          >
            3. 烹饪步骤 ({steps.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('review')}
            className={`py-2 px-3 border-b-2 transition-colors ${
              activeTab === 'review' ? 'border-[#C85A32] text-[#C85A32] font-semibold' : 'border-transparent text-[#7A7268] hover:text-[#2C2723]'
            }`}
          >
            4. 心得与复盘
          </button>
        </div>

        {/* Modal Form Content */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: BASIC INFO & PHOTO */}
          {activeTab === 'basic' && (
            <div className="space-y-4">
              {/* Photo Upload Area */}
              <div>
                <label className="block text-xs font-semibold text-[#2C2723] mb-1.5">
                  菜品配图 / 封面照片
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-white rounded-xl border border-[#EADBCE]">
                  <div className="w-36 h-28 rounded-lg overflow-hidden bg-[#FAF7F2] border border-[#EADBCE] flex items-center justify-center shrink-0">
                    {coverImage ? (
                      <img src={coverImage} alt="封面预览" className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-center p-2 text-xs text-[#9A9085]">
                        <Camera className="w-6 h-6 mx-auto mb-1 text-[#C85A32]/60" />
                        <span>暂无配图</span>
                      </div>
                    )}
                  </div>

                  <div className="flex-1 space-y-2 text-xs text-[#7A7268]">
                    <p>支持从手机相册或电脑上传实拍菜品照片，系统会自动完成轻量压缩，保存在您的本地手帐中。</p>
                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer px-3 py-1.5 bg-[#C85A32] text-white rounded-md font-medium hover:bg-[#B34C26] transition-colors flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5" />
                        <span>{isProcessingImage ? '压缩中...' : coverImage ? '更换照片' : '上传菜品实拍图'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleCoverUpload}
                          disabled={isProcessingImage}
                        />
                      </label>
                      {coverImage && (
                        <button
                          type="button"
                          onClick={() => setCoverImage('')}
                          className="px-2.5 py-1.5 border border-[#EADBCE] rounded-md hover:bg-[#FAF7F2] text-[#9A9085]"
                        >
                          移除
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Dish Title & Subtitle */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                    菜品名称 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="例如：日式照烧三文鱼"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                    手帐副标 / 风味特质
                  </label>
                  <input
                    type="text"
                    placeholder="例如：外焦里嫩，甜咸适口的下饭快手菜"
                    value={subtitle}
                    onChange={(e) => setSubtitle(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>
              </div>

              {/* Authoritative Category & Subcategory Two-Tier Classification */}
              <div className="p-4 bg-white rounded-xl border border-[#EADBCE] space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-[#F0E6DC]">
                  <span className="text-xs font-bold text-[#2C2723] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#C85A32]" />
                    <span>分类与细分标签体系</span>
                  </span>
                  <span className="text-[11px] text-[#7A7268]">精准二级细分便于按风味检索</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                      主分类 (一级大类)
                    </label>
                    <select
                      value={category}
                      onChange={(e) => handleCategoryChange(e.target.value as RecipeCategory)}
                      className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32] font-semibold text-[#2C2723]"
                    >
                      {ALL_CATEGORIES_LIST.map((cat) => (
                        <option key={cat} value={cat}>
                          {CATEGORY_TAXONOMY[cat].icon} {cat} ({CATEGORY_TAXONOMY[cat].shortLabel})
                        </option>
                      ))}
                    </select>
                    <span className="text-[10px] text-[#7A7268] mt-1 block">
                      {CATEGORY_TAXONOMY[category].description}
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                      二级细分 (权威分类) <span className="text-[#C85A32]">*</span>
                    </label>
                    <select
                      value={subCategory}
                      onChange={(e) => setSubCategory(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-[#FAF7F2] border border-[#C85A32] rounded-lg focus:outline-hidden focus:border-[#C85A32] font-bold text-[#C85A32]"
                    >
                      {getSubcategoriesForCategory(category).map((sub) => (
                        <option key={sub.id} value={sub.id}>
                          {sub.icon} {sub.label} —— {sub.desc}
                        </option>
                      ))}
                    </select>
                    <span className="text-[10px] text-[#C85A32] mt-1 block truncate">
                      包含：{getSubcategoriesForCategory(category).find((s) => s.id === subCategory)?.desc}
                    </span>
                  </div>
                </div>
              </div>

              {/* Cuisine & Weather Stamp */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                    菜系 / 风味风格标签 (选填)
                  </label>
                  <input
                    type="text"
                    placeholder="如：港式满记风味 / 江浙本帮 / 法式经典"
                    value={cuisine}
                    onChange={(e) => setCuisine(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                    手帐天气印记
                  </label>
                  <select
                    value={weatherStamp}
                    onChange={(e) => setWeatherStamp(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  >
                    {PRESET_WEATHER.map((w) => (
                      <option key={w} value={w}>{w}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Prep time, Cook time, Base servings, Difficulty */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-xl border border-[#EADBCE]">
                <div>
                  <label className="block text-xs text-[#7A7268] mb-1">备料用时 (分钟)</label>
                  <input
                    type="number"
                    min="1"
                    max="300"
                    value={prepTimeMinutes}
                    onChange={(e) => setPrepTimeMinutes(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-sm font-mono border border-[#EADBCE] rounded-md focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#7A7268] mb-1">烹饪用时 (分钟)</label>
                  <input
                    type="number"
                    min="1"
                    max="300"
                    value={cookTimeMinutes}
                    onChange={(e) => setCookTimeMinutes(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-sm font-mono border border-[#EADBCE] rounded-md focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#7A7268] mb-1">基准分量 (人份)</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={baseServings}
                    onChange={(e) => setBaseServings(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-sm font-mono border border-[#EADBCE] rounded-md focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#7A7268] mb-1">难度等级</label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(Number(e.target.value))}
                    className="w-full px-2 py-1.5 text-sm border border-[#EADBCE] rounded-md focus:outline-hidden focus:border-[#C85A32]"
                  >
                    <option value="1">1星 (极易小白)</option>
                    <option value="2">2星 (快手日常)</option>
                    <option value="3">3星 (需控火候)</option>
                    <option value="4">4星 (精细烘焙/宴客)</option>
                    <option value="5">5星 (大师级大菜)</option>
                  </select>
                </div>
              </div>

              {/* Cookware Utensils */}
              <div>
                <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                  所需厨具 / 器皿 (以顿号或逗号隔开)
                </label>
                <input
                  type="text"
                  placeholder="如：厚底铸铁锅、硅胶铲、厨房秤"
                  value={utensilsText}
                  onChange={(e) => setUtensilsText(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                />
              </div>
            </div>
          )}

          {/* TAB 2: INGREDIENTS */}
          {activeTab === 'ingredients' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-[#7A7268]">
                  填写食材与用量，后续可在菜谱详情中根据用餐人数自由无损倍数缩放。
                </p>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => addIngredientRow('main')}
                    className="px-2 py-1 text-xs bg-[#FAF7F2] border border-[#EADBCE] hover:border-[#C85A32] text-[#C85A32] rounded flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ 主料</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => addIngredientRow('seasoning')}
                    className="px-2 py-1 text-xs bg-[#FAF7F2] border border-[#EADBCE] hover:border-[#C08A3E] text-[#C08A3E] rounded flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ 调料</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => addIngredientRow('garnish')}
                    className="px-2 py-1 text-xs bg-[#FAF7F2] border border-[#EADBCE] hover:border-[#5F7A4D] text-[#5F7A4D] rounded flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ 配菜</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                {ingredients.map((ing, idx) => (
                  <div key={ing.id || idx} className="flex items-center gap-2 bg-white p-2.5 rounded-lg border border-[#EADBCE]">
                    {/* Category Selector */}
                    <select
                      value={ing.category}
                      onChange={(e) => updateIngredient(idx, 'category', e.target.value)}
                      className="text-xs py-1 px-1.5 border border-[#EADBCE] rounded bg-[#FAF7F2] shrink-0"
                    >
                      <option value="main">主料</option>
                      <option value="seasoning">调料</option>
                      <option value="garnish">点缀</option>
                    </select>

                    {/* Ingredient Name */}
                    <input
                      type="text"
                      placeholder="食材名称 (如 五花肉)"
                      value={ing.name}
                      onChange={(e) => updateIngredient(idx, 'name', e.target.value)}
                      className="flex-2 min-w-[100px] text-xs px-2.5 py-1.5 border border-[#EADBCE] rounded focus:outline-hidden focus:border-[#C85A32]"
                    />

                    {/* Quantity */}
                    <input
                      type="number"
                      step="any"
                      placeholder="用量"
                      value={ing.amount}
                      onChange={(e) => updateIngredient(idx, 'amount', Number(e.target.value) || 0)}
                      className="w-16 text-xs px-2 py-1.5 font-mono border border-[#EADBCE] rounded focus:outline-hidden focus:border-[#C85A32]"
                    />

                    {/* Unit */}
                    <input
                      type="text"
                      placeholder="单位 (克/勺)"
                      value={ing.unit}
                      onChange={(e) => updateIngredient(idx, 'unit', e.target.value)}
                      className="w-16 text-xs px-2 py-1.5 border border-[#EADBCE] rounded focus:outline-hidden focus:border-[#C85A32]"
                    />

                    {/* Optional Note */}
                    <input
                      type="text"
                      placeholder="备注 (如 切薄片)"
                      value={ing.note || ''}
                      onChange={(e) => updateIngredient(idx, 'note', e.target.value)}
                      className="flex-1 text-xs px-2 py-1.5 border border-[#EADBCE] rounded hidden sm:block focus:outline-hidden focus:border-[#C85A32]"
                    />

                    {/* Remove */}
                    <button
                      type="button"
                      onClick={() => removeIngredient(idx)}
                      className="p-1 text-[#9A9085] hover:text-rose-600 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: STEPS */}
          {activeTab === 'steps' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-[#7A7268]">
                  细致记录每一步骤的火候、操作时序与避坑诀窍，下厨时一目了然。
                </p>
                <button
                  type="button"
                  onClick={addStepRow}
                  className="px-3 py-1.5 text-xs bg-[#C85A32] text-white rounded-md hover:bg-[#B34C26] flex items-center gap-1 font-medium"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>添加步骤</span>
                </button>
              </div>

              <div className="space-y-4">
                {steps.map((st, idx) => (
                  <div key={st.id || idx} className="bg-white p-4 rounded-xl border border-[#EADBCE] space-y-3">
                    <div className="flex items-center justify-between gap-2 border-b border-[#F0E6DC] pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#FAF7F2] border border-[#C85A32] text-[#C85A32] text-xs font-mono font-bold flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <input
                          type="text"
                          placeholder="步骤标题 (如 焯水去腥)"
                          value={st.title}
                          onChange={(e) => updateStep(idx, 'title', e.target.value)}
                          className="font-bold text-sm text-[#2C2723] border-b border-transparent focus:border-[#C85A32] focus:outline-hidden px-1"
                        />
                      </div>

                      <div className="flex items-center gap-2 text-xs">
                        <select
                          value={st.heat || '中火'}
                          onChange={(e) => updateStep(idx, 'heat', e.target.value)}
                          className="py-1 px-2 border border-[#EADBCE] rounded bg-[#FAF7F2] text-xs text-[#C85A32]"
                        >
                          <option value="大火">大火</option>
                          <option value="中火">中火</option>
                          <option value="小火">小火</option>
                          <option value="微火">微火</option>
                          <option value="关火焖">关火焖</option>
                          <option value="烤箱预热/烘烤">烤箱烘烤</option>
                        </select>

                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min="1"
                            max="180"
                            placeholder="分钟"
                            value={st.durationMinutes || ''}
                            onChange={(e) => updateStep(idx, 'durationMinutes', Number(e.target.value) || 0)}
                            className="w-14 py-1 px-1.5 font-mono text-xs border border-[#EADBCE] rounded"
                          />
                          <span className="text-[#9A9085]">分</span>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeStep(idx)}
                          className="p-1 text-[#9A9085] hover:text-rose-600 rounded ml-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <textarea
                        rows={2}
                        placeholder="具体操作要点..."
                        value={st.description}
                        onChange={(e) => updateStep(idx, 'description', e.target.value)}
                        className="w-full text-xs p-2.5 bg-[#FAF7F2]/50 border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                      />
                    </div>

                    <div>
                      <input
                        type="text"
                        placeholder="💡 避坑要点 / 小贴士 (可选，例如：切勿提前加盐)"
                        value={st.tip || ''}
                        onChange={(e) => updateStep(idx, 'tip', e.target.value)}
                        className="w-full text-xs px-2.5 py-1.5 bg-[#FFFDF9] border border-[#E8DCC4] rounded-md text-[#8C5D1E] focus:outline-hidden"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: REVIEW & REFLECTIONS */}
          {activeTab === 'review' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-xl border border-[#EADBCE] space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                      烹饪手帐记录日期
                    </label>
                    <input
                      type="date"
                      value={cookDate}
                      onChange={(e) => setCookDate(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-[#EADBCE] rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                      风味口感评分 ({tasteRating}星)
                    </label>
                    <div className="flex items-center gap-1.5 pt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setTasteRating(star)}
                          className="text-[#C08A3E] p-0.5"
                        >
                          <Star className={`w-5 h-5 ${star <= tasteRating ? 'fill-current' : 'opacity-30'}`} />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Tasting Notes */}
                <div>
                  <label className="block text-xs font-semibold text-[#2C2723] mb-1">
                    口感与风味手记
                  </label>
                  <textarea
                    rows={2}
                    placeholder="例如：肉皮弹糯，汤汁浓郁咸甜适中，米饭绝配..."
                    value={tastingNotes}
                    onChange={(e) => setTastingNotes(e.target.value)}
                    className="w-full text-xs p-2.5 border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                {/* Pitfalls & Lessons */}
                <div>
                  <label className="block text-xs font-semibold text-[#C85A32] mb-1">
                    避坑复盘与下次改进
                  </label>
                  <textarea
                    rows={2}
                    placeholder="例如：糖色可以再多熬3秒，下次准备加入熟芝麻增香..."
                    value={pitfallsAndLessons}
                    onChange={(e) => setPitfallsAndLessons(e.target.value)}
                    className="w-full text-xs p-2.5 border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                {/* Pairing */}
                <div>
                  <label className="block text-xs font-semibold text-[#5F7A4D] mb-1">
                    搭配建议 (主食 / 饮品 / 配菜)
                  </label>
                  <input
                    type="text"
                    placeholder="例如：配刚出锅的五常大米饭、冰镇酸梅汤"
                    value={pairingSuggestions}
                    onChange={(e) => setPairingSuggestions(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                {/* Diner Feedback */}
                <div>
                  <label className="block text-xs font-semibold text-[#C08A3E] mb-1">
                    亲友食客点评
                  </label>
                  <input
                    type="text"
                    placeholder="例如：“全家光盘，要求列入每周固定菜单！”"
                    value={dinerFeedback}
                    onChange={(e) => setDinerFeedback(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32]"
                  />
                </div>

                {/* Sticker Badges */}
                <div>
                  <label className="block text-xs font-semibold text-[#2C2723] mb-2">
                    选择手帐贴纸印章
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {PRESET_STICKERS.map((stk) => {
                      const isSelected = selectedStickers.includes(stk);
                      return (
                        <button
                          key={stk}
                          type="button"
                          onClick={() => toggleSticker(stk)}
                          className={`text-xs px-2.5 py-1 rounded-full border transition-all ${
                            isSelected
                              ? 'bg-[#C85A32] text-white border-[#C85A32]'
                              : 'bg-[#FAF7F2] text-[#7A7268] border-[#EADBCE] hover:border-[#C85A32]'
                          }`}
                        >
                          {stk}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Modal Footer Controls */}
          <div className="pt-4 border-t border-[#EADBCE] flex items-center justify-between">
            <div className="flex items-center gap-2">
              {activeTab !== 'basic' && (
                <button
                  type="button"
                  onClick={() => {
                    const tabs: Array<'basic' | 'ingredients' | 'steps' | 'review'> = ['basic', 'ingredients', 'steps', 'review'];
                    const prevIdx = tabs.indexOf(activeTab) - 1;
                    if (prevIdx >= 0) setActiveTab(tabs[prevIdx]);
                  }}
                  className="px-3 py-1.5 text-xs text-[#7A7268] hover:text-[#2C2723]"
                >
                  ← 上一步
                </button>
              )}
              {activeTab !== 'review' && (
                <button
                  type="button"
                  onClick={() => {
                    const tabs: Array<'basic' | 'ingredients' | 'steps' | 'review'> = ['basic', 'ingredients', 'steps', 'review'];
                    const nextIdx = tabs.indexOf(activeTab) + 1;
                    if (nextIdx < tabs.length) setActiveTab(tabs[nextIdx]);
                  }}
                  className="px-3 py-1.5 text-xs bg-[#FAF7F2] border border-[#EADBCE] rounded text-[#2C2723] hover:bg-[#F0E6DC]"
                >
                  下一步 →
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 text-xs text-[#7A7268] hover:text-[#2C2723] rounded-lg transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold text-white bg-[#C85A32] hover:bg-[#B34C26] rounded-lg shadow-sm transition-all flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>保存入手帐</span>
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
};
