import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Recipe } from './types/recipe';
import { UserProfile } from './types/auth';
import { getCurrentUser } from './utils/authService';
import { 
  getUserRecipes, 
  getPublicSquareRecipes, 
  saveUserRecipe, 
  deleteUserRecipe, 
  cloneRecipeToMyJournal, 
  toggleLikeRecipe, 
  addCommentToRecipe, 
  getRecipeById 
} from './utils/multiUserStorage';
import { getGitHubConfig, syncRecipesToGitHub, GitHubConfig } from './utils/githubSync';
import { Header } from './components/Header';
import { RecipeCard } from './components/RecipeCard';
import { RecipeDetail } from './components/RecipeDetail';
import { RecipeEditor } from './components/RecipeEditor';
import { IngredientsPantryView } from './components/IngredientsPantryView';
import { CookingNotesView } from './components/CookingNotesView';
import { ShareCardModal } from './components/ShareCardModal';
import { BackupView } from './components/BackupView';
import { KitchenTimer } from './components/KitchenTimer';
import { PWAInstallModal } from './components/PWAInstallModal';
import { GitHubSyncModal } from './components/GitHubSyncModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { CulinarySquareView } from './components/CulinarySquareView';
import { SharedRecipePage } from './components/SharedRecipePage';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { 
  CATEGORY_TAXONOMY, 
  ALL_CATEGORIES_LIST, 
  getSubcategoriesForCategory 
} from './types/categories';
import { Search, Heart, Plus, BookOpen, Smartphone, Sparkles, User, LogIn, Check, Tag } from 'lucide-react';

export default function App() {
  // Multi-user authentication state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => getCurrentUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Recipes state (isolated per user)
  const [recipes, setRecipes] = useState<Recipe[]>(() => getUserRecipes(getCurrentUser()));
  const [publicRecipes, setPublicRecipes] = useState<Recipe[]>(() => getPublicSquareRecipes());

  // Navigation & Selected Recipe
  const [activeView, setActiveView] = useState<'journal' | 'square' | 'pantry' | 'notes' | 'backup'>('journal');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [sharedRecipeTarget, setSharedRecipeTarget] = useState<Recipe | null>(null);

  // Modals & Editors
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [sharingRecipe, setSharingRecipe] = useState<Recipe | null>(null);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);

  // GitHub Auto-Sync Config
  const [githubConfig, setGithubConfig] = useState<GitHubConfig>(() => getGitHubConfig());
  const [syncToast, setSyncToast] = useState<string | null>(null);
  const isFirstRender = useRef(true);

  // Kitchen Timer State
  const [timerState, setTimerState] = useState<{ isOpen: boolean; minutes: number; label: string } | null>(null);

  // Filter & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('all');
  const [favoritesOnly, setFavoritesOnly] = useState(false);

  // Deep linking check on mount
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const recipeId = urlParams.get('recipeId') || urlParams.get('recipe');
      if (recipeId) {
        const found = getRecipeById(recipeId);
        if (found) {
          setSharedRecipeTarget(found);
        }
      }
    } catch (e) {
      console.warn('URL parsing error', e);
    }
  }, []);

  // Listen to master recipe updates & auth changes across windows / tabs
  useEffect(() => {
    const handleStorageChange = () => {
      setRecipes(getUserRecipes(currentUser));
      setPublicRecipes(getPublicSquareRecipes());
    };
    const handleAuthChange = (e: CustomEvent) => {
      const newUser = e.detail;
      setCurrentUser(newUser);
      setRecipes(getUserRecipes(newUser));
      setPublicRecipes(getPublicSquareRecipes());
    };

    window.addEventListener('recipes-updated', handleStorageChange);
    window.addEventListener('auth-state-changed', handleAuthChange as EventListener);
    return () => {
      window.removeEventListener('recipes-updated', handleStorageChange);
      window.removeEventListener('auth-state-changed', handleAuthChange as EventListener);
    };
  }, [currentUser]);

  // Sync recipes to GitHub if configured
  useEffect(() => {
    if (!isFirstRender.current && githubConfig.autoSync && githubConfig.token) {
      syncRecipesToGitHub(githubConfig, recipes)
        .then((res) => {
          if (res.success) {
            setSyncToast(`已实时备份至 GitHub (${res.commitSha})`);
            setTimeout(() => setSyncToast(null), 3000);
          }
        })
        .catch(console.error);
    }
    isFirstRender.current = false;
  }, [recipes, githubConfig]);

  // Handle Save Recipe (isolated to current user)
  const handleSaveRecipe = (recipe: Recipe) => {
    const saved = saveUserRecipe(recipe, currentUser);
    setRecipes(getUserRecipes(currentUser));
    setPublicRecipes(getPublicSquareRecipes());
    setIsEditorOpen(false);
    setEditingRecipe(null);
    if (selectedRecipe && selectedRecipe.id === recipe.id) {
      setSelectedRecipe(saved);
    }
    setSyncToast(`菜谱《${saved.title}》已保存${saved.isPublic ? '并公开至食味广场' : '至私密手帐'}`);
    setTimeout(() => setSyncToast(null), 3000);
  };

  // Handle Delete Recipe
  const handleDeleteRecipe = (id: string) => {
    deleteUserRecipe(id, currentUser);
    setRecipes(getUserRecipes(currentUser));
    setPublicRecipes(getPublicSquareRecipes());
    if (selectedRecipe?.id === id) {
      setSelectedRecipe(null);
    }
  };

  // Handle Toggle Favorite
  const handleToggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const target = recipes.find((r) => r.id === id);
    if (target) {
      const updated = { ...target, isFavorite: !target.isFavorite };
      saveUserRecipe(updated, currentUser);
      setRecipes(getUserRecipes(currentUser));
      if (selectedRecipe?.id === id) {
        setSelectedRecipe(updated);
      }
    }
  };

  // Handle Clone Recipe to Current User's Journal
  const handleCloneRecipe = (sourceRecipe: Recipe) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    const cloned = cloneRecipeToMyJournal(sourceRecipe, currentUser);
    setRecipes(getUserRecipes(currentUser));
    setActiveView('journal');
    setSelectedRecipe(cloned);
    setSharedRecipeTarget(null);
    setSyncToast(`已成功收录《${sourceRecipe.title}》到您的手帐本！`);
    setTimeout(() => setSyncToast(null), 3500);
  };

  // Handle Like on Public or Private Recipe
  const handleToggleLike = (recipeId: string) => {
    toggleLikeRecipe(recipeId, currentUser);
    setRecipes(getUserRecipes(currentUser));
    setPublicRecipes(getPublicSquareRecipes());
    if (sharedRecipeTarget && sharedRecipeTarget.id === recipeId) {
      const refreshed = getRecipeById(recipeId);
      if (refreshed) setSharedRecipeTarget(refreshed);
    }
    if (selectedRecipe && selectedRecipe.id === recipeId) {
      const refreshed = getRecipeById(recipeId);
      if (refreshed) setSelectedRecipe(refreshed);
    }
  };

  // Handle Add Comment
  const handleAddComment = (recipeId: string, content: string) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    addCommentToRecipe(recipeId, currentUser.displayName, currentUser.avatarUrl, content);
    setRecipes(getUserRecipes(currentUser));
    setPublicRecipes(getPublicSquareRecipes());
    if (sharedRecipeTarget && sharedRecipeTarget.id === recipeId) {
      const refreshed = getRecipeById(recipeId);
      if (refreshed) setSharedRecipeTarget(refreshed);
    }
  };

  const handleStartTimer = (minutes: number, label: string) => {
    setTimerState({ isOpen: true, minutes, label });
  };

  // User Stats Calculation for UserProfileModal
  const publicRecipeCount = useMemo(() => {
    return recipes.filter((r) => r.isPublic).length;
  }, [recipes]);

  const totalLikesReceived = useMemo(() => {
    if (!currentUser) return 0;
    return recipes.reduce((sum, r) => sum + (r.likesCount || 0), 0);
  }, [recipes, currentUser]);

  // Filtered recipe list for personal journal
  const filteredRecipes = useMemo(() => {
    return recipes.filter((r) => {
      // Category filter
      if (selectedCategory !== 'all' && r.category !== selectedCategory) return false;
      // Subcategory filter
      if (selectedSubCategory !== 'all' && r.subCategory !== selectedSubCategory) return false;
      // Favorite filter
      if (favoritesOnly && !r.isFavorite) return false;
      // Search query filter (matches title, cuisine, ingredients, category, subcategory)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const inTitle = r.title.toLowerCase().includes(q);
        const inSubtitle = r.subtitle?.toLowerCase().includes(q);
        const inCuisine = r.cuisine?.toLowerCase().includes(q);
        const inCategory = r.category?.toLowerCase().includes(q);
        const inSubCategory = r.subCategory?.toLowerCase().includes(q);
        const inIngredients = r.ingredients.some((i) => i.name.toLowerCase().includes(q));
        if (!inTitle && !inSubtitle && !inCuisine && !inCategory && !inSubCategory && !inIngredients) return false;
      }
      return true;
    });
  }, [recipes, selectedCategory, selectedSubCategory, favoritesOnly, searchQuery]);

  const categories = [
    { id: 'all', label: '全部菜谱', icon: '📖' },
    ...ALL_CATEGORIES_LIST.map((c) => ({
      id: c,
      label: c,
      icon: CATEGORY_TAXONOMY[c].icon
    }))
  ];

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#2C2723] flex flex-col font-sans">
      {/* 1. Header (Top Bar Contract) */}
      <Header
        activeView={activeView}
        setActiveView={(view) => {
          setActiveView(view);
          setSelectedRecipe(null);
          setSharedRecipeTarget(null);
        }}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onNewRecipe={() => {
          setEditingRecipe(null);
          setIsEditorOpen(true);
        }}
        onOpenInstall={() => setIsInstallModalOpen(true)}
        onOpenGitHub={() => setIsGitHubModalOpen(true)}
      />

      {/* Realtime Notification Toast */}
      {syncToast && (
        <div className="fixed top-20 right-6 z-50 bg-[#2C2723] text-amber-100 text-xs py-2 px-3.5 rounded-lg border border-[#EADBCE] shadow-xl flex items-center gap-2 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{syncToast}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* VIEW 0: DEEP LINK SHARED RECIPE VIEW */}
        {sharedRecipeTarget ? (
          <SharedRecipePage
            recipe={sharedRecipeTarget}
            currentUser={currentUser}
            onBackToApp={() => {
              setSharedRecipeTarget(null);
              window.history.replaceState({}, '', window.location.pathname);
            }}
            onCloneRecipe={handleCloneRecipe}
            onToggleLike={handleToggleLike}
            onAddComment={handleAddComment}
            onRequireLogin={() => setIsAuthModalOpen(true)}
          />
        ) : selectedRecipe ? (
          /* VIEW 1: DETAIL RECIPE VIEW */
          <RecipeDetail
            recipe={selectedRecipe}
            onBack={() => setSelectedRecipe(null)}
            onEdit={(rec) => {
              setEditingRecipe(rec);
              setIsEditorOpen(true);
            }}
            onDelete={handleDeleteRecipe}
            onShare={(rec) => setSharingRecipe(rec)}
            onUpdateRecipe={(updated) => {
              handleSaveRecipe(updated);
              setSelectedRecipe(updated);
            }}
            onStartTimer={handleStartTimer}
          />
        ) : (
          <>
            {/* VIEW 2: MAIN JOURNAL CATALOG */}
            {activeView === 'journal' && (
              <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24">
                
                {/* Hero / Scrapbook Masthead */}
                <div className="mb-8 p-6 sm:p-8 bg-white border border-[#EADBCE] rounded-2xl paper-shadow bg-notebook-dots relative overflow-hidden">
                  <div className="absolute top-0 right-10 transform -translate-y-1/2 pointer-events-none">
                    <div className="washi-tape px-6 py-1 bg-[#5F7A4D]/80 text-emerald-50 text-xs font-mono tracking-wider uppercase">
                      PERSONAL JOURNAL
                    </div>
                  </div>

                  <div className="max-w-2xl">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs font-serif tracking-widest text-[#C85A32] uppercase block">
                        私房手作 · 烟火记录
                      </span>
                      {currentUser ? (
                        <span className="text-[11px] text-[#5A5248] bg-[#FAF7F2] border border-[#EADBCE] px-2 py-0.5 rounded-full">
                          专属大厨：{currentUser.displayName}
                        </span>
                      ) : (
                        <button
                          onClick={() => setIsAuthModalOpen(true)}
                          className="text-[11px] text-[#C85A32] hover:underline"
                        >
                          (点击登录以享受多端独立手帐)
                        </button>
                      )}
                    </div>
                    <h1 className="text-2xl sm:text-4xl font-bold font-journal-title text-[#2C2723] leading-tight mb-3">
                      今日下厨，把日子过得热气腾腾
                    </h1>
                    <p className="text-xs sm:text-sm text-[#7A7268] leading-relaxed font-serif">
                      详细记录食材用量、关键火候时序与心得复盘。每一张手帐页，都是留给餐桌的温柔回忆。
                    </p>
                  </div>

                  {/* Search & Filter Toolbar */}
                  <div className="mt-6 pt-5 border-t border-[#F0E6DC] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                    {/* Search Bar */}
                    <div className="relative flex-1 max-w-md">
                      <Search className="w-4 h-4 text-[#9A9085] absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="搜索菜名、食材 (如：黑虎虾、抹茶、生抽)..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-9 pr-4 py-2 text-xs bg-[#FAF7F2] border border-[#EADBCE] rounded-lg focus:outline-hidden focus:border-[#C85A32] transition-colors"
                      />
                      {searchQuery && (
                        <button
                          onClick={() => setSearchQuery('')}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[#9A9085] hover:text-[#2C2723]"
                        >
                          ✕
                        </button>
                      )}
                    </div>

                    {/* Favorites Toggle & Square shortcut */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setActiveView('square')}
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border border-[#C85A32]/40 bg-amber-50/50 text-[#C85A32] hover:bg-amber-100/50 transition-colors"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>去食味广场找灵感</span>
                      </button>

                      <button
                        onClick={() => setFavoritesOnly(!favoritesOnly)}
                        className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-colors shrink-0 ${
                          favoritesOnly
                            ? 'bg-rose-50 text-rose-600 border-rose-200 shadow-2xs'
                            : 'bg-[#FAF7F2] text-[#7A7268] border-[#EADBCE] hover:text-[#2C2723]'
                        }`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${favoritesOnly ? 'fill-current' : ''}`} />
                        <span>{favoritesOnly ? '只看常做收藏' : '筛选收藏'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Category Segmented Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pt-4 text-xs no-scrollbar">
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setSelectedCategory(cat.id);
                          setSelectedSubCategory('all');
                        }}
                        className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors flex items-center gap-1.5 ${
                          selectedCategory === cat.id
                            ? 'bg-[#2C2723] text-white shadow-xs'
                            : 'text-[#7A7268] hover:text-[#2C2723] hover:bg-[#FAF7F2]'
                        }`}
                      >
                        <span>{cat.icon}</span>
                        <span>{cat.label}</span>
                      </button>
                    ))}
                  </div>

                  {/* Secondary Subcategory Filter Row */}
                  {selectedCategory !== 'all' ? (
                    <div className="mt-3 pt-3 border-t border-[#F0E6DC] flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
                      <span className="text-[11px] font-semibold text-[#7A7268] shrink-0 flex items-center gap-1">
                        <Tag className="w-3.5 h-3.5 text-[#C85A32]" />
                        <span>{selectedCategory}细分：</span>
                      </span>
                      <button
                        onClick={() => setSelectedSubCategory('all')}
                        className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium transition-colors ${
                          selectedSubCategory === 'all'
                            ? 'bg-[#C85A32] text-white shadow-2xs'
                            : 'bg-[#FAF7F2] text-[#7A7268] hover:text-[#2C2723] border border-[#EADBCE]'
                        }`}
                      >
                        全部细分
                      </button>
                      {getSubcategoriesForCategory(selectedCategory as any).map((sub) => {
                        const count = recipes.filter(
                          (r) => r.category === selectedCategory && r.subCategory === sub.id
                        ).length;
                        return (
                          <button
                            key={sub.id}
                            onClick={() => setSelectedSubCategory(sub.id)}
                            title={sub.desc}
                            className={`px-2.5 py-1 rounded-md whitespace-nowrap font-medium transition-colors flex items-center gap-1 ${
                              selectedSubCategory === sub.id
                                ? 'bg-[#C85A32] text-white font-bold shadow-2xs'
                                : 'bg-[#FAF7F2] text-[#7A7268] hover:text-[#2C2723] border border-[#EADBCE]'
                            }`}
                          >
                            <span>{sub.icon}</span>
                            <span>{sub.label}</span>
                            {count > 0 && (
                              <span className={`text-[10px] ml-0.5 px-1 py-0.2 rounded-full ${
                                selectedSubCategory === sub.id ? 'bg-white/25 text-white' : 'bg-stone-200/70 text-[#7A7268]'
                              }`}>
                                {count}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="mt-3 pt-3 border-t border-[#F0E6DC] flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
                      <span className="text-[11px] font-semibold text-[#7A7268] shrink-0 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-[#C85A32]" />
                        <span>甜点细分直达：</span>
                      </span>
                      {CATEGORY_TAXONOMY['烘焙甜点'].subcategories.map((sub) => (
                        <button
                          key={sub.id}
                          onClick={() => {
                            setSelectedCategory('烘焙甜点');
                            setSelectedSubCategory(sub.id);
                          }}
                          className="px-2.5 py-1 rounded-md whitespace-nowrap font-medium bg-[#FAF7F2] hover:bg-white text-[#7A7268] hover:text-[#C85A32] border border-[#EADBCE] transition-colors flex items-center gap-1 shrink-0"
                        >
                          <span>{sub.icon}</span>
                          <span>{sub.label}</span>
                        </button>
                      ))}
                    </div>
                  )}

                </div>

                {/* Recipe Cards Grid */}
                <div className="flex items-center justify-between mb-4 px-1">
                  <div className="text-xs text-[#7A7268]">
                    我的手帐收录 <span className="font-mono font-semibold text-[#2C2723]">{filteredRecipes.length}</span> 道私房菜谱
                    {selectedCategory !== 'all' && ` · ${selectedCategory}`}
                    {selectedSubCategory !== 'all' && ` · ${selectedSubCategory}`}
                  </div>
                </div>

                {filteredRecipes.length === 0 ? (
                  <div className="bg-white border border-dashed border-[#EADBCE] rounded-2xl p-12 text-center max-w-md mx-auto">
                    <BookOpen className="w-10 h-10 text-[#C85A32]/40 mx-auto mb-3" />
                    <h3 className="text-base font-bold text-[#2C2723] font-journal-title mb-1">
                      手帐本空空如也，来记一笔吧！
                    </h3>
                    <p className="text-xs text-[#7A7268] mb-4">
                      您可以点击下方按钮录入第一道私房菜，或者前往食味广场将厨友分享的好菜一键收录。
                    </p>
                    <div className="flex items-center justify-center gap-3">
                      <button
                        onClick={() => {
                          setEditingRecipe(null);
                          setIsEditorOpen(true);
                        }}
                        className="px-4 py-2 bg-[#C85A32] text-white text-xs font-semibold rounded-lg hover:bg-[#B34C26] transition-colors inline-flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" />
                        <span>新建私房食谱</span>
                      </button>
                      <button
                        onClick={() => setActiveView('square')}
                        className="px-4 py-2 bg-white border border-[#EADBCE] text-[#2C2723] text-xs font-semibold rounded-lg hover:bg-[#FAF7F2] transition-colors inline-flex items-center gap-1.5"
                      >
                        <Sparkles className="w-4 h-4 text-[#C85A32]" />
                        <span>浏览广场灵感</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredRecipes.map((recipe) => (
                      <RecipeCard
                        key={recipe.id}
                        recipe={recipe}
                        onSelect={(rec) => setSelectedRecipe(rec)}
                        onShare={(rec) => setSharingRecipe(rec)}
                        onToggleFavorite={handleToggleFavorite}
                      />
                    ))}
                  </div>
                )}

              </div>
            )}

            {/* VIEW 3: CULINARY SQUARE (PUBLIC EXPLORATION) */}
            {activeView === 'square' && (
              <CulinarySquareView
                recipes={publicRecipes}
                currentUser={currentUser}
                onOpenRecipe={(rec) => setSelectedRecipe(rec)}
                onCloneRecipe={handleCloneRecipe}
                onToggleLike={handleToggleLike}
                onShareRecipe={(rec) => setSharingRecipe(rec)}
                onRequireLogin={() => setIsAuthModalOpen(true)}
              />
            )}

            {/* VIEW 4: INGREDIENTS PANTRY & SHOPPING LIST */}
            {activeView === 'pantry' && (
              <IngredientsPantryView
                recipes={recipes}
                onOpenRecipe={(rec) => setSelectedRecipe(rec)}
              />
            )}

            {/* VIEW 5: COOKING NOTES & REVIEWS WALL */}
            {activeView === 'notes' && (
              <CookingNotesView
                recipes={recipes}
                onOpenRecipe={(rec) => setSelectedRecipe(rec)}
                onShareRecipe={(rec) => setSharingRecipe(rec)}
              />
            )}

            {/* VIEW 6: BACKUP & DATA MANAGEMENT */}
            {activeView === 'backup' && (
              <BackupView
                recipes={recipes}
                onReloadRecipes={(recs) => {
                  setRecipes(recs);
                }}
                onOpenGitHub={() => setIsGitHubModalOpen(true)}
                onOpenInstall={() => setIsInstallModalOpen(true)}
              />
            )}
          </>
        )}
      </main>

      {/* Kitchen Offline State Indicator */}
      <OfflineIndicator />

      {/* Floating Kitchen Timer (When Active) */}
      {timerState?.isOpen && (
        <KitchenTimer
          initialMinutes={timerState.minutes}
          label={timerState.label}
          onClose={() => setTimerState(null)}
        />
      )}

      {/* Recipe Editor Modal / Drawer */}
      {isEditorOpen && (
        <RecipeEditor
          initialRecipe={editingRecipe}
          onSave={handleSaveRecipe}
          onCancel={() => {
            setIsEditorOpen(false);
            setEditingRecipe(null);
          }}
        />
      )}

      {/* Share Card Modal */}
      {sharingRecipe && (
        <ShareCardModal
          recipe={sharingRecipe}
          onClose={() => setSharingRecipe(null)}
        />
      )}

      {/* PWA App Install Modal */}
      <PWAInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* GitHub Sync Modal */}
      <GitHubSyncModal
        isOpen={isGitHubModalOpen}
        recipes={recipes}
        onClose={() => setIsGitHubModalOpen(false)}
        onConfigUpdated={(cfg) => setGithubConfig(cfg)}
      />

      {/* Multi-Channel Auth Modal (Phone, Email/Password, WeChat, Alipay, Google) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setRecipes(getUserRecipes(user));
          setPublicRecipes(getPublicSquareRecipes());
        }}
      />

      {/* User Profile Modal */}
      {currentUser && (
        <UserProfileModal
          isOpen={isProfileModalOpen}
          user={currentUser}
          userRecipeCount={recipes.length}
          publicRecipeCount={publicRecipeCount}
          totalLikesReceived={totalLikesReceived}
          onClose={() => setIsProfileModalOpen(false)}
          onUserUpdated={(updated) => {
            setCurrentUser(updated);
          }}
          onLogout={() => {
            setCurrentUser(null);
            setRecipes(getUserRecipes(null));
            setPublicRecipes(getPublicSquareRecipes());
          }}
        />
      )}

      {/* Quiet Footer */}
      <footer className="border-t border-[#EADBCE] bg-[#FAF7F2] py-6 text-center text-xs text-[#9A9085]">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>食味手记 · 让每一次下厨都成为值得珍藏的手帐记忆</span>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsInstallModalOpen(true)}
              className="hover:text-[#C85A32] transition-colors"
            >
              手机App安装
            </button>
            <span>·</span>
            <button
              onClick={() => setIsGitHubModalOpen(true)}
              className="hover:text-[#C85A32] transition-colors"
            >
              GitHub 实时备份
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveView('square')}
              className="hover:text-[#C85A32] transition-colors"
            >
              食味广场
            </button>
            <span>·</span>
            <span>每个账号手帐独立隔离</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
